package client2;

import java.io.*;
import java.net.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.util.concurrent.*;

public class Client2 {

	public static void main(String[] args) {
//		runLocalScripts();
		try (Socket client2 = new Socket("192.168.1.85", 2500); // Change to server IP Address
			BufferedReader in = new BufferedReader(new InputStreamReader(client2.getInputStream()));
			PrintWriter out = new PrintWriter(client2.getOutputStream(), true);
			Scanner scanner = new Scanner(System.in);
			) 
		{
			String serverMessage;
			System.out.println("Attempting to connect with server " + client2.getInetAddress() + ":" + client2.getPort());
			serverMessage = in.readLine();
			System.out.println(serverMessage);
			
			
			while (true) {
                System.out.println("\nChoose an option:");
                System.out.println("1. Request Task");
                System.out.println("2. Queue Status");
                System.out.println("3. Cancel Tasks");
                System.out.println("4. Task History");
                System.out.println("5. Exit");
                String choice = scanner.nextLine();

                if (choice.equals("1")) {
                	String service = "";
                	String priority = "";
                	while(true) {
	                    System.out.print("Enter Service Number (2001–2005): ");
	                    service = scanner.nextLine();
	
	                    System.out.print("Enter Priority (1=High, 2=Medium, 3=Low): ");
	                    priority = scanner.nextLine();
	                    
	                    if((service.equals("2001") || service.equals("2002") || service.equals("2003") || service.equals("2004") || service.equals("2005")) && (priority.equals("1") || priority.equals("2") || priority.equals("3"))) {           
	                    	break;
	                    }
	                    System.out.println("Enter the allowed values!");
                	}

                    String request = "REQUEST_TASK;" + service + ";Client2;" + priority;
                    out.println(request);
                } else if (choice.equals("2")) {
                    out.println("QUEUE_STATUS");
                } else if (choice.equals("3")){
                	System.out.print("Enter Task ID: ");
                	String taskId = scanner.nextLine();
                	out.println("CANCEL_TASK;"+taskId);
                }
                else if (choice.equals("4")) {
                    out.println("TASK_HISTORY");
                } else if (choice.equals("5")) {
                    System.out.println("Exiting.");
                    out.println("exit");
                    break;
                } else {
                    System.out.println("Invalid option.");
                    continue;
                }

                // Wait and display server response
                System.out.print("[Server] ");
                while ((serverMessage = in.readLine()) != "") {
                    System.out.println(serverMessage);
                    if (serverMessage.startsWith("===END")) {
                    	break;
                    } 
                }
            }
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void runLocalScripts() {
		try {
			System.out.println("Running local scripts...");
	        ProcessBuilder quotaPb = new ProcessBuilder("bash", "scripts/quota_check.sh");
	        Process quotaProcess = quotaPb.start();
	        ProcessBuilder reportPb = new ProcessBuilder("bash", "scripts/resource_report.sh");
	        Process reportProcess = reportPb.start();

	        int quotaExitCode = quotaProcess.waitFor();
	        System.out.println("[Quota Script finished with exit code " + quotaExitCode + "]\n");
	        int reportExitCode = reportProcess.waitFor();
	        System.out.println("[Report Script finished with exit code " + reportExitCode + "]\n");

	    } catch (IOException | InterruptedException e) {
	        System.err.println("[Error running script]: " + e.getMessage());
	    }
	}
}
