package client1;

import java.io.*;
import java.net.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.util.concurrent.*;

public class Client1 {

	public static void main(String[] args) {
		runLocalScripts();

		try (Socket client1 = new Socket("192.168.1.85", 2500); // Change to server IP Address
			BufferedReader in = new BufferedReader(new InputStreamReader(client1.getInputStream()));
			PrintWriter out = new PrintWriter(client1.getOutputStream(), true);
			Scanner scanner = new Scanner(System.in);
			) 
		{
			String serverMessage;
			System.out.println("Attempting to connect with server " + client1.getInetAddress() + ":" + client1.getPort());
			serverMessage = in.readLine();
			System.out.println(serverMessage);
			
			
			while (true) {
                System.out.println("\nChoose an option:");
                System.out.println("1. Request Task");
                System.out.println("2. Queue Status");
                System.out.println("3. Cancel Tasks");
                System.out.println("4. Task History");
                System.out.println("5. Exit");
                String choice = scanner.nextLine();

                if (choice.equals("1")) {
                    System.out.print("Enter Service Number (2001–2005): ");
                    String service = scanner.nextLine();

                    System.out.print("Enter Priority (1=High, 2=Medium, 3=Low): ");
                    String priority = scanner.nextLine();

                    String request = "REQUEST_TASK;" + service + ";Client1;" + priority;
                    out.println(request);
                } else if (choice.equals("2")) {
                    out.println("QUEUE_STATUS");
                } else if (choice.equals("3")){
                	System.out.print("Enter Task ID: ");
                	String taskId = scanner.nextLine();
                	out.println("CANCEL_TASK;"+taskId);
                }
                else if (choice.equals("4")) {
                    out.println("TASK_HISTORY");
                } else if (choice.equals("5")) {
                    System.out.println("Exiting.");
                    out.println("exit");
                    break;
                } else {
                    System.out.println("Invalid option.");
                    continue;
                }

                // Wait and display server response
                System.out.print("[Server] ");
                while ((serverMessage = in.readLine()) != "") {
                    System.out.println(serverMessage);
                    if (serverMessage.startsWith("===END")) {
                    	break;
                    } 
                }
            }
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}
	
	public static void runLocalScripts() {
		try {
	        ProcessBuilder permsPb = new ProcessBuilder("bash", "Scripts/fix_perms.sh");
	        Process permsProcess = permsPb.start();
	        
	        ProcessBuilder loginPb = new ProcessBuilder("bash", "Scripts/login_audit.sh");
	        Process loginProcess = loginPb.start();

	        int permsExitCode = permsProcess.waitFor();
	        System.out.println("[fix_perms script finished with exit code " + permsExitCode + "]\n");
	        
	        int loginExitCode = loginProcess.waitFor();
	        System.out.println("[login_audit script finished with exit code " + loginExitCode + "]\n");

	    } catch (IOException | InterruptedException e) {
	        System.err.println("[Error running script]: " + e.getMessage());
	    }
	}
}
