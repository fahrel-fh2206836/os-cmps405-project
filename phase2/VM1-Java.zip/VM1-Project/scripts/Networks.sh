#!/bin/bash

#Note: This should run in a seperate dedicated terminal. To stop it, Press Ctrl + Z

#Creating the directory if it doesnt exist
mkdir -p PingDirectory


ping_client() {

	local client_name=$1

	outputFile="PingDirectory/TimeStamp.txt"

	#Create the timestamp file
	touch "$outputFile"

	#Modify permissions to read and write for owner only
	chmod 600 "$outputFile"

	echo -e "\n\033[1;34mPinging $client_name at $(date +"%Y-%m-%d %H:%M:%S")...\033[0m"

	#Replace google.com with target VM IP address
	ping "$client_name" -s 500 -c 10 >> "$outputFile"

	echo -e "\033[1;32mPing results for $client_name saved to $outputFile\033[0m"

}

while true
do
	#ClientVM2 
	#ping_client "192.168.67.195"

	#ClientVM3 
	ping_client "192.168.18.5"

	#Every 10 seconds interval
	echo -e "\n\033[1;33mWaiting for 10 seconds before the next ping cycle...\033[0m"
	sleep 10 
done


#Replace the ip's 



