package server;

public class TaskRunner extends Thread {
    private final Task task;

    public TaskRunner(Task task) {
        this.task = task;
    }

    public void run() {
        String scriptName = task.getScriptName();

        synchronized (Server.activeScripts) {
            if (Server.activeScripts.contains(scriptName)) {
                Server.logTask("REJECTED", task);
                return;
            }
            Server.activeScripts.add(scriptName);
        }

        try {
        	Server.logTask("EXECUTING", task);
            Process p = new ProcessBuilder("./" + scriptName).start();
            int result = p.waitFor();
            Server.logTask(result == 0 ? "COMPLETED" : "ERROR", task);
        } catch (Exception e) {
        	Server.logTask("ERROR", task);
        } finally {
            synchronized (Server.activeScripts) {
            	Server.activeScripts.remove(scriptName);
            }
        }
    }
}
