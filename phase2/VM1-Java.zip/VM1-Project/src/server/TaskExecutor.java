package server;

public class TaskExecutor implements Runnable {

    @Override
    public void run() {
        while (true) {
            try {
                Task task = Server.taskQueue.take();
                new TaskRunner(task).start();
            } catch (InterruptedException e) {
                System.err.println("Executor interrupted.");
            }
        }
    }
}
