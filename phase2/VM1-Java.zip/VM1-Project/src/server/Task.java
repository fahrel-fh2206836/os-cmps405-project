package server;
public class Task implements Comparable<Task> {
    int id, serviceNumber, priority;
    String client;

    public Task(int id, int serviceNumber, String client, int priority) {
        this.id = id;
        this.serviceNumber = serviceNumber;
        this.client = client;
        this.priority = priority;
    }

    public String getScriptName() {
        return switch (serviceNumber) {
            case 2001 -> "scripts/user_setup.sh";
            case 2002 -> "scripts/dir_perms.sh";
            case 2003 -> "scripts/system_monitor.sh";
            case 2004 -> "scripts/file_audit.sh";
            case 2005 -> "scripts/MySQL_login_" + client + ".sh";
            default -> "unknown.sh";
        };
    }

    public int compareTo(Task other) {
        if (this.priority != other.priority)
            return Integer.compare(this.priority, other.priority);
        return Integer.compare(this.id, other.id);
    }
}