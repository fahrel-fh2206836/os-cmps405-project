package server;

import java.io.*;
import java.net.*;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.TimeUnit;

public class Service implements Runnable {

	private final Socket socket;

	public Service(Socket socket) {
		this.socket = socket;
	}

	@Override
	public void run() {
		try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
				PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {
			if (!runNetworkCheck()) {
				out.println(Server.formatResponse("ERROR", "Network check failed. Cannot proceed."));
				socket.close();
				in.close();
				out.close();
				return;
			}
			out.println("Client-Server Connection established!");

			while (true) {
				String request = in.readLine();
				System.out.println(request);
				if (request == null || request.equalsIgnoreCase("exit"))
					break;

				String[] parts = request.split(";");
				String response = null;

				switch (parts[0]) {
				case "REQUEST_TASK":
					response = handleTaskRequest(parts, out);
					out.println(response);
					break;
				case "QUEUE_STATUS":
					response = getQueueStatus();
					out.println(response);
					break;
				case "CANCEL_TASK":
					response = handleCancelTask(parts);
					out.println(response);
					break;
				case "TASK_HISTORY":
					response = getTaskHistory();
					out.println(response);
					break;
				default:
					response = Server.formatResponse("ERROR", "Invalid command");
					out.println(response);
				}

				System.out.println("[DEBUG]: " + response);
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				out.println("===END OF RESPONSE===");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private boolean runNetworkCheck() {
		try {
			Process p = new ProcessBuilder("bash", "scripts/Networks.sh").start();
			boolean finished = p.waitFor(2, TimeUnit.SECONDS);

			if (!finished) {
				p.destroy(); // kill after checking connections for 2 seconds.
				return true;
			}

			int exitCode = p.exitValue();
			return exitCode == 0;
		} catch (Exception e) {
			System.err.println("Network.sh execution failed: " + e.getMessage());
			return false;
		}
	}

	public String handleTaskRequest(String[] parts, PrintWriter pw) {
		if (parts.length != 4)
			return Server.formatResponse("ERROR", "Invalid request format.");

		int serviceNum = Integer.parseInt(parts[1]);
		String clientName = parts[2];
		int priority = Integer.parseInt(parts[3]);

		long now = System.currentTimeMillis();
		Task task = new Task(++Server.taskIdCounter, serviceNum, clientName, priority, pw);
		if (Server.clientLastSubmission.containsKey(clientName)
				&& now - Server.clientLastSubmission.get(clientName) < 300000) {
			Server.logTask("REJECTED", task);
			return Server.formatResponse("REJECTED", "Rate limit exceeded. Wait 5 minutes.");
		}

		Server.clientLastSubmission.put(clientName, now);
		Server.taskQueue.offer(task);
		return Server.formatResponse("QUEUED", "Task queued with ID " + task.id);
	}

	private String handleCancelTask(String[] parts) {
		if (parts.length != 2) {
			return Server.formatResponse("ERROR", "Invalid CANCEL_TASK format.");
		}

		int taskIdToCancel;
		try {
			taskIdToCancel = Integer.parseInt(parts[1]);
		} catch (NumberFormatException e) {
			return Server.formatResponse("ERROR", "Invalid Task ID.");
		}

		// Search in the queue
		Task toRemove = null;
		for (Task t : Server.taskQueue) {
			if (t.id == taskIdToCancel) {
				toRemove = t;
				break;
			}
		}

		if (toRemove != null) {
			Server.taskQueue.remove(toRemove);
			Server.logTask("CANCELLED", toRemove);
			return Server.formatResponse("COMPLETED", "TaskID " + taskIdToCancel + " cancelled successfully.");
		}

		return Server.formatResponse("REJECTED", "Task not found or already running.");
	}

	public String getQueueStatus() {
		String msg = "Pending Tasks:\n";
		for (Task t : Server.taskQueue) {
			msg += "TaskID=" + t.id + ", Script=" + t.getScriptName() + ",Priority=" + t.priority + ", Client="
					+ t.client + "\n";
		}
		return Server.formatResponse("COMPLETED", msg);
	}

	public String getTaskHistory() {
		try {
			File file = new File("task_log.txt");
			if (!file.exists())
				return Server.formatResponse("COMPLETED", "History");
			String content = new String(Files.readAllBytes(file.toPath()));
			return Server.formatResponse("COMPLETED", "History:\n" + content);
		} catch (IOException e) {
			return Server.formatResponse("ERROR", "Failed to read log.");
		}
	}
}
