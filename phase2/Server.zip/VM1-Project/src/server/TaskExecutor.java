package server;

public class TaskExecutor implements Runnable {

    @Override
    public void run() {
        while (true) {
        	if(Server.taskQueue.isEmpty()) {
        		continue;
        	}
            Task task = Server.taskQueue.peek();
			new TaskRunner(task).start();
        }
    }
}
