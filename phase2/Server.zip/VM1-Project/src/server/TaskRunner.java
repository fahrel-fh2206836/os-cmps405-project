package server;

public class TaskRunner extends Thread {
	private final Task task;

	public TaskRunner(Task task) {
		this.task = task;
	}

	public void run() {
		String scriptName = task.getScriptName();

		synchronized (Server.activeScripts) {
			if (Server.activeScripts.contains(scriptName)) {
//            	System.out.println("Active Running Scripts:" + Server.activeScripts.toString());       	
				return;
			}
//            System.out.println("Active Running Scripts:" + Server.activeScripts.toString());
			try {
				// Remove from queue
//				System.out.println("Queue Before:" + Server.taskQueue.toString());
				Server.taskQueue.take();
//				System.out.println("Queue After:" + Server.taskQueue.toString());
				task.pw.println(Server.formatResponse("EXECUTING", "Task ID: " + this.task.id + " is executing..."));
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				task.pw.println(Server.formatResponse("ERROR",
						"Task ID: " + this.task.id + "  encountered execution failure."));
				Server.logTask("ERROR", task);
			}
			Server.activeScripts.add(scriptName);
		}

		try {
//			Thread.sleep(10000);
			Process p = new ProcessBuilder("./" + scriptName).start();
			int result = p.waitFor();
			Server.logTask(result == 0 ? "COMPLETED" : "ERROR", task);
			if (result != 0) {
				task.pw.println(Server.formatResponse("ERROR",
						"Task ID: " + this.task.id + "  encountered execution failure."));
			} else {
				task.pw.println(Server.formatResponse("COMPLETED",
						"Task ID: " + this.task.id + "  completed execution."));
			}
		} catch (Exception e) {
			task.pw.println(Server.formatResponse("ERROR", "Task ID: " +this.task.id+"  encountered execution failure."));
			Server.logTask("ERROR", task);
		} finally {
			synchronized (Server.activeScripts) {
				Server.activeScripts.remove(scriptName);
			}
		}
	}

}
