package server;

import java.io.FileWriter;
import java.io.IOException;
import java.net.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.PriorityBlockingQueue;

public class Server {

	public static final Map<String, Long> clientLastSubmission = new ConcurrentHashMap<>();
	public static final PriorityBlockingQueue<Task> taskQueue = new PriorityBlockingQueue<>();
	public static final Set<String> activeScripts = ConcurrentHashMap.newKeySet();
	public static int taskIdCounter = 100;
	
	public static void main(String[] args) throws IOException {
		ServerSocket server = new ServerSocket(2500);
		System.out.println("Server listening on port " + 2500 + "...");
		
		new Thread(new TaskExecutor()).start();
		while (true) {
			Socket nextClient = server.accept();
			System.out.println("[*] New connection received from " + server.getInetAddress());
			new Thread(new Service(nextClient)).start();
		}
	}

	public static String formatResponse(String status, String message) {
		String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
		return status + ";" + timestamp + ";" + message;
	}
	

	public static void logTask(String status, Task task) {
		String msg = "TaskID="+task.id+", Script="+task.getScriptName()+", Client="+task.client+", Status="+status;
		System.out.println(msg);
		try (FileWriter fw = new FileWriter("task_log.txt", true)) {
			fw.write(msg + "\n");
		} catch (IOException e) {
			System.err.println("Failed to write task log.");
		}
	}
}
