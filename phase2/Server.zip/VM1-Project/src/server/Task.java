package server;

import java.io.PrintWriter;

public class Task implements Comparable<Task> {
    int id, serviceNumber, priority;
    String client;
    PrintWriter pw;

    public Task(int id, int serviceNumber, String client, int priority, PrintWriter pw) {
        this.id = id;
        this.serviceNumber = serviceNumber;
        this.client = client;
        this.priority = priority;
        this.pw = pw;
    }

    public String getScriptName() {
    	String sqlUser = client.equals("Client1") ? "dev_lead1" : "ops_lead1";
    	String scriptName = "";
    		
        switch (serviceNumber) {
            case 2001: 
            	scriptName = "scripts/user_setup.sh";
            	break;
            case 2002: 
            	scriptName = "scripts/dir_perms.sh";
            	break;
            case 2003: 
            	scriptName = "scripts/system_monitor.sh";
            	break;
            case 2004: 
            	scriptName = "scripts/file_audit.sh";
            	break;
            case 2005: 
            	scriptName = "scripts/MySQL_login_" + sqlUser + ".sh";
            	break;
            default:
            	scriptName = "unknown.sh";
        };
        return scriptName;
    }

    public int compareTo(Task other) {
        if (this.priority != other.priority)
            return Integer.compare(this.priority, other.priority);
        return Integer.compare(this.id, other.id);
    }
}